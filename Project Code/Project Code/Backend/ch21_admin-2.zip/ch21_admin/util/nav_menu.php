<main>
    <p><a href="index.php?action=show_admin_menu">Admin menu</a></p>
    <p><a href="index.php?action=left_off">Where did I leave off?</a></p>
    <p><a href="index.php?action=show_order_manager">Order Manager</a></p>
    <p><a href="index.php?action=logout">Logout</a></p>
</main>