<?php

// Start session management and include necessary functions
session_start();
require_once('model/database.php');
require_once('model/admin_db.php');

//unset($_SESSION['is_valid_admin']);

// Get the action to perform
$action = filter_input(INPUT_POST, 'action');

if ($action == NULL) {
    $action = filter_input(INPUT_GET, 'action');
    if ($action == NULL) {
        $action = 'show_admin_menu';
    }
}

// If the user isn't logged in, force the user to login
if (!isset($_SESSION['is_valid_admin'])) {
    $action = 'login';
}

//echo $action;
//print_r($_SESSION);

// Perform the specified action
switch($action) {
    case 'login':
        $username = filter_input(INPUT_POST, 'username');
        $password = filter_input(INPUT_POST, 'password');
        if (is_valid_admin_login($username, $password)) {
            $_SESSION['is_valid_admin'] = true;
            $_SESSION['currently_logged_in_user_username'] = $username;
            $_SESSION['my_favorite_frog'] = "Buddy"; //NOTE: Can make up any session key you want and give it a value

            //Exchange username for user id, and store that in the session
            $stmt = $db->prepare("SELECT * FROM users WHERE username = :username"); 
            $stmt->bindParam(":username", $username);
            $stmt->execute();
            $row = $stmt->fetch();
            $user_id = $row["id"];
            $_SESSION['currently_logged_in_user_id'] = $user_id;

            include('view/admin_menu.php');
        } else {
            $login_message = 'You must login to view this page.';
            include('view/login.php');
        }
        break;
    case 'left_off':
        include("view/left_off.php");
        break;
    case 'show_admin_menu':
        include('view/admin_menu.php');
        break;
    case 'show_product_manager':
        include('view/product_manager.php');
        break;
    case 'show_order_manager':
        include('view/order_manager.php');
        break;
    case 'logout':
        $_SESSION = array();   // Clear all session data from memory
        session_destroy();     // Clean up the session ID
        $login_message = 'You have been logged out.';
        include('view/login.php');
        break;
}
?>